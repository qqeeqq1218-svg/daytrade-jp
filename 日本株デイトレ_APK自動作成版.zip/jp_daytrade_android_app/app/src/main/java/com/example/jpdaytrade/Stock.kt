package com.example.jpdaytrade

data class Stock(
    val code: String,
    val name: String,
    val price: Double,
    val changePct: Double,
    val volumeRatio: Double,
    val turnoverOku: Double,
    val vwapAbove: Boolean,
    val breakout: Boolean,
    val trend: String,
    val score: Double
)