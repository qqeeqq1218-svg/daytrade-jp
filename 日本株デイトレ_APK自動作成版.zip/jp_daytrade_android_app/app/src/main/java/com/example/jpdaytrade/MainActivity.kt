package com.example.jpdaytrade

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: StockAdapter
    private lateinit var status: TextView

    private val stocks = listOf(
        "7203" to "トヨタ自動車", "8306" to "三菱UFJ", "9984" to "ソフトバンクG",
        "6857" to "アドバンテスト", "8035" to "東京エレクトロン", "7011" to "三菱重工業",
        "6501" to "日立製作所", "6758" to "ソニーG", "4063" to "信越化学",
        "9101" to "日本郵船", "9104" to "商船三井", "1605" to "INPEX",
        "5020" to "ENEOS", "6098" to "リクルートHD", "9432" to "NTT",
        "7267" to "ホンダ", "6146" to "ディスコ", "6367" to "ダイキン",
        "7735" to "SCREEN", "8316" to "三井住友FG", "8411" to "みずほFG",
        "8766" to "東京海上HD", "8058" to "三菱商事", "8001" to "伊藤忠商事",
        "8031" to "三井物産", "7974" to "任天堂", "9433" to "KDDI",
        "9983" to "ファーストリテイリング", "6920" to "レーザーテック",
        "6723" to "ルネサス"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.statusText)
        adapter = StockAdapter(emptyList())

        findViewById<RecyclerView>(R.id.recycler).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<Button>(R.id.refreshButton).setOnClickListener {
            loadStocks()
        }

        loadStocks()
    }

    private fun loadStocks() {
        status.text = "株価データ取得中…"
        thread {
            val result = stocks.mapNotNull { (code, name) ->
                try { fetchStock(code, name) } catch (_: Exception) { null }
            }.sortedByDescending { it.score }

            runOnUiThread {
                adapter.update(result)
                status.text =
                    if (result.isEmpty()) "取得できませんでした。取引時間外またはデータ元の仕様変更の可能性があります。"
                    else "${result.size}銘柄を取得しました"
            }
        }
    }

    private fun fetchStock(code: String, name: String): Stock? {
        val u = URL("https://query1.finance.yahoo.com/v8/finance/chart/$code.T?interval=5m&range=2d&includePrePost=false")
        val c = (u.openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0")
        }
        if (c.responseCode != 200) return null
        val text = c.inputStream.bufferedReader().use { it.readText() }
        val root = JSONObject(text)
        val result = root.getJSONObject("chart").getJSONArray("result").optJSONObject(0) ?: return null
        val meta = result.getJSONObject("meta")
        val timestamps = result.getJSONArray("timestamp")
        val quote = result.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)

        val opens = quote.getJSONArray("open")
        val highs = quote.getJSONArray("high")
        val lows = quote.getJSONArray("low")
        val closes = quote.getJSONArray("close")
        val volumes = quote.getJSONArray("volume")

        data class Bar(val t:Long,val o:Double,val h:Double,val l:Double,val c:Double,val v:Double)
        val bars = mutableListOf<Bar>()
        for (i in 0 until timestamps.length()) {
            if (opens.isNull(i) || highs.isNull(i) || lows.isNull(i) || closes.isNull(i) || volumes.isNull(i)) continue
            bars += Bar(
                timestamps.getLong(i),
                opens.getDouble(i), highs.getDouble(i), lows.getDouble(i),
                closes.getDouble(i), volumes.getDouble(i)
            )
        }
        if (bars.isEmpty()) return null

        val latest = bars.last()
        val prevClose = when {
            meta.has("chartPreviousClose") -> meta.optDouble("chartPreviousClose", latest.o)
            meta.has("previousClose") -> meta.optDouble("previousClose", latest.o)
            else -> latest.o
        }
        val change = if (prevClose != 0.0) (latest.c - prevClose) / prevClose * 100.0 else 0.0

        fun dayKey(t:Long): String {
            val millis = (t + 9*3600L) * 1000L
            return java.time.Instant.ofEpochMilli(millis).toString().substring(0,10)
        }
        val todayKey = dayKey(latest.t)
        val today = bars.filter { dayKey(it.t) == todayKey }
        if (today.isEmpty()) return null

        var pv = 0.0
        var vol = 0.0
        var dayHigh = Double.NEGATIVE_INFINITY
        today.forEach {
            val typical = (it.h + it.l + it.c) / 3.0
            pv += typical * it.v
            vol += it.v
            if (it.h > dayHigh) dayHigh = it.h
        }
        val vwap = if (vol > 0) pv / vol else latest.c
        val vwapAbove = latest.c >= vwap

        val recent = today.takeLast(4)
        val trend = if (recent.size >= 3) {
            val pct = (recent.last().c - recent.first().c) / recent.first().c * 100.0
            when {
                pct > 0.6 -> "強い上昇"
                pct > 0.15 -> "上昇"
                pct < -0.25 -> "下降"
                else -> "横ばい"
            }
        } else "横ばい"

        val prior = bars.dropLast(today.size).map { it.v }.filter { it > 0 }
        val avgPrior = if (prior.isNotEmpty()) prior.average() else vol / today.size
        val avgToday = vol / today.size
        val volumeRatio = if (avgPrior > 0) avgToday / avgPrior else 1.0
        val turnoverOku = latest.c * vol / 100_000_000.0
        val highPos = if (dayHigh > 0) latest.c / dayHigh * 100.0 else 100.0
        val breakout = latest.c >= dayHigh * 0.997

        var score = 0.0
        score += min(20.0, max(0.0, (volumeRatio - 1.0) / 3.0 * 20.0))
        score += min(20.0, turnoverOku / 300.0 * 20.0)
        score += when {
            change in 2.0..10.0 -> 15.0
            change > 0 && change < 2.0 -> 8.0
            change > 10.0 -> 6.0
            else -> 0.0
        }
        if (vwapAbove) score += 15.0
        score += max(0.0, min(7.0, (highPos - 90.0) / 10.0 * 7.0))
        if (breakout) score += 8.0
        score += when (trend) {
            "強い上昇" -> 15.0
            "上昇" -> 11.0
            "横ばい" -> 4.0
            else -> 0.0
        }
        score = max(0.0, min(100.0, score))

        return Stock(code, name, latest.c, change, volumeRatio, turnoverOku, vwapAbove, breakout, trend, score)
    }
}