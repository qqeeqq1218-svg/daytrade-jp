package com.example.jpdaytrade

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.NumberFormat
import java.util.Locale

class StockAdapter(private var items: List<Stock>) :
    RecyclerView.Adapter<StockAdapter.Holder>() {

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.title)
        val subtitle: TextView = v.findViewById(R.id.subtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_stock, parent, false)
        return Holder(v)
    }

    override fun onBindViewHolder(h: Holder, position: Int) {
        val s = items[position]
        val yen = NumberFormat.getNumberInstance(Locale.JAPAN).format(s.price)
        val label = when {
            s.score >= 85 -> "🔥 強い"
            s.score >= 75 -> "◎ 有力"
            s.score >= 65 -> "○ 監視"
            else -> "△ 様子見"
        }
        h.title.text = "${position + 1}. ${s.code} ${s.name}  ${s.score.toInt()}点  $label"
        h.subtitle.text =
            "¥$yen  前日比 ${"%.2f".format(s.changePct)}%  出来高 ${"%.2f".format(s.volumeRatio)}x\n" +
            "売買代金 ${"%.1f".format(s.turnoverOku)}億円  VWAP ${if (s.vwapAbove) "上" else "下"}  ${s.trend}"
    }

    override fun getItemCount() = items.size

    fun update(newItems: List<Stock>) {
        items = newItems
        notifyDataSetChanged()
    }
}